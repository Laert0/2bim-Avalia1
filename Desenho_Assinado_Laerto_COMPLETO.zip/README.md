# Desenho Assinado

Página que recebe um número inteiro entre 1 e 100 e devolve uma figura em SVG, assinada com o e-mail verificado da conta Google usada no login.

## Identificação

Nome: Laerto Marcos Santin
RA: 2025207381
URL: https://SEU-SITE.pages.dev

## Cloudflare Pages

Framework preset: `None`
Build command: vazio
Build output directory: `public`

## Estrutura

- `public/index.html`
- `public/style.css`
- `public/script.js`
- `lib/desenho.js`
- `functions/api/desenho.js`
- `evidencias/exemplo.svg`

## Configuração

Crie um OAuth Client Google do tipo Web application. Substitua o Client ID em `public/index.html` e configure o mesmo valor no Cloudflare Pages como variável `GOOGLE_CLIENT_ID`. Cadastre a URL `https://SEU-SITE.pages.dev` como Authorized JavaScript origin.

Não coloque tokens, senhas ou arquivos `.env` no repositório.
