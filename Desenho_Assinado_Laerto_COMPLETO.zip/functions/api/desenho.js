import { gerarDesenho, numeroValido } from "../../lib/desenho.js";
const json=(b,s)=>new Response(JSON.stringify(b),{status:s,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}});
export async function onRequest({request,env}){
if(request.method!=="POST")return json({error:"method_not_allowed"},405);
let body;try{const raw=await request.text();if(!raw.trim())return json({error:"invalid_body"},400);body=JSON.parse(raw)}catch{return json({error:"invalid_json"},400)}
if(!numeroValido(body?.numero))return json({error:"numero_invalido"},400);
const auth=request.headers.get("Authorization")||"",m=auth.match(/^Bearer\s+(.+)$/i);if(!m)return json({error:"unauthorized"},401);
if(!env.GOOGLE_CLIENT_ID)return json({error:"server_configuration_error"},500);
let info;try{const r=await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(m[1])}`);if(r.status!==200)return json({error:"invalid_token"},401);info=await r.json()}catch{return json({error:"token_validation_failed"},401)}
if(info.aud!==env.GOOGLE_CLIENT_ID||info.email_verified!=="true"||!info.email)return json({error:"unauthorized"},401);
return new Response(gerarDesenho(body.numero,info.email),{status:200,headers:{"Content-Type":"image/svg+xml; charset=utf-8","Cache-Control":"no-store"}});
}
